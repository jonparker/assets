using System;
using System.Threading.Tasks;
using System.Collections.Generic;
using Amazon.Lambda.Core;
using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.DataModel;
using Amazon.DynamoDBv2.DocumentModel;
using ERMDataAPI.Common;

namespace ERMDataAPI
{
    public class Display
    {
        public async Task<IEnumerable<ResultsItem>> Handle(Request request, ILambdaContext lambdaContext)
        {
           var clientFactory = new AwsClientFactory<AmazonDynamoDBClient>();
           var dynamoDBClient = clientFactory.GetAwsClient();
           
           var resultList = new List<ResultsItem>();
           using (var context = new DynamoDBContext(dynamoDBClient))
           {
               var scanCondition = new ScanCondition(nameof(ResultsItem.Date), ScanOperator.LessThanOrEqual, DateTime.Today);
               var search = context.ScanAsync<ResultsItem>(new[] { scanCondition }, new DynamoDBOperationConfig
               {
                   OverrideTableName = Environment.GetEnvironmentVariable("DYNAMODB_TABLE_NAME"),
                   SkipVersionCheck = true
               });

               while (!search.IsDone)
               {
                   var entities = await search.GetNextSetAsync();
                   resultList.AddRange(entities);
               }
           }

           Console.WriteLine("Got results from Dynamo: " + resultList.Count);
           return resultList;
       }
    }
}
