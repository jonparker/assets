using System;
using Amazon.Runtime;

namespace ERMDataAPI.Common
{
    public class AwsClientFactory<T> : IAwsClientFactory<T> where T : AmazonServiceClient, new() {
        public T GetAwsClient()
        {
          return (T) Activator.CreateInstance(typeof(T));
        }
    }
}