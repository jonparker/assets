using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace ERMDataAPI.Common
{
    public interface IResultsItemRepository
    {
        Task<IEnumerable<T>> GetById<T>(string id, CancellationToken cancellationToken);

        Task Save(ResultsItem item, CancellationToken cancellationToken);
    }
}