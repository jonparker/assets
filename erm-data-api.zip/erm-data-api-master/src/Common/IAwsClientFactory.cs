namespace ERMDataAPI.Common
{
    public interface IAwsClientFactory<out T>
    {
        T GetAwsClient();
    }
}