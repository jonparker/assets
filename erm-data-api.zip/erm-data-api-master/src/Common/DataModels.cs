using System;
using Amazon.Lambda.Core;
using Amazon.DynamoDBv2.DataModel;

[assembly:LambdaSerializer(typeof(Amazon.Lambda.Serialization.Json.JsonSerializer))]

namespace ERMDataAPI.Common
{

    public class Request {
      public string Message { get;set; }
    }

    public class Response {
      public string Message { get; set; }
    }
    public class ResultsItem
    {
      [DynamoDBHashKey]
      public string resultId { get; set; }
      [DynamoDBProperty]
      public DateTime Date { get; set; }
      [DynamoDBProperty]
      public string MeterCode { get; set; }
      [DynamoDBProperty]
      public string DataType { get; set; }
      [DynamoDBProperty]
      public double Minimum { get; set; }
      [DynamoDBProperty]
      public double Maximum { get; set; }
      [DynamoDBProperty]
      public double Median { get; set; }
    }
    public class StandardDataRecord
    {
      public string MeterCode { get; set; }
      public string DataType { get; set; }
      public DateTime Date { get; set; }
      public double DataValue { get; set; }
    }

    public enum FileFormat
    {
      LP,
      TOU
    }
}
