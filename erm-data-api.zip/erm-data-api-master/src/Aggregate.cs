using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Threading;
using Amazon.Lambda.Core;
using Amazon.S3.Model;
using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.DataModel;
using Amazon.S3;
using ERMDataAPI.Common;
using Csv;
using MathNet.Numerics.Statistics;

namespace ERMDataAPI
{
    public class Aggregate
    {
        public Aggregate()
        {
            CultureInfo.CurrentCulture = new CultureInfo("en-AU"); // Ensure date parsing uses correct format.
        }

       private async Task InsertRecord(IAmazonDynamoDB dynamoDBClient, ResultsItem resultsItem)
       {
           using (var context = new DynamoDBContext(dynamoDBClient))
           {
               await context.SaveAsync(resultsItem, new DynamoDBOperationConfig
               {
                   OverrideTableName = Environment.GetEnvironmentVariable("DYNAMODB_TABLE_NAME"),
                   SkipVersionCheck = true
               });
           }
       }

       public const string TOU_METER_CODE_HEADER = "MeterCode";
       public const string TOU_DATA_TYPE_HEADER = "DataType";
       public const string TOU_DATETIME_HEADER = "DateTime";
       public const string TOU_DATA_VALUE = "Energy";

       public const string LP_METER_CODE_HEADER = "MeterPoint Code";
       public const string LP_DATA_TYPE_HEADER = "Data Type";
       public const string LP_DATETIME_HEADER = "Date/Time";
       public const string LP_DATA_VALUE = "Data Value";
       
       private StandardDataRecord GetRecord(FileFormat fileFormat, ICsvLine record)
       {
           if (fileFormat == FileFormat.LP)
               return new StandardDataRecord
               {
                   MeterCode = record[LP_METER_CODE_HEADER],
                   DataType = record[LP_DATA_TYPE_HEADER],
                   Date = DateTime.Parse(record[LP_DATETIME_HEADER]).Date,
                   DataValue = double.Parse(record[LP_DATA_VALUE])
               };
           
           return new StandardDataRecord
           {
               MeterCode = record[TOU_METER_CODE_HEADER],
               DataType = record[TOU_DATA_TYPE_HEADER],
               Date = DateTime.Parse(record[TOU_DATETIME_HEADER]).Date,
               DataValue = double.Parse(record[TOU_DATA_VALUE])
           };
       }

       private async Task<IEnumerable<string>> DownloadFromS3(string prefix)
       {
           var s3Bucket = Environment.GetEnvironmentVariable("S3_INJEST_BUCKET_NAME");
           var clientFactory = new AwsClientFactory<AmazonS3Client>();
           var s3Client = clientFactory.GetAwsClient();

           var listFilesResponse = await s3Client.ListObjectsAsync(new ListObjectsRequest
           {
               BucketName = s3Bucket,
               Prefix = prefix + "/"
           });

           var results = new List<string>();

           foreach (var s3File in listFilesResponse.S3Objects)
           {
               var getObjectResponse = await s3Client.GetObjectAsync(new GetObjectRequest
               {
                   BucketName = s3File.BucketName,
                   Key = s3File.Key
               });
               var inputPath = Path.GetTempFileName();
               Console.WriteLine($"Got file from S3: {s3File.Key}, temp file: {inputPath}");
               await getObjectResponse.WriteResponseStreamToFileAsync(inputPath, true, CancellationToken.None);
               results.Add(inputPath);
           }

           return results;
       }

       private async Task ProcessFiles(FileFormat fileFormat)
       {
           var fileNames = await DownloadFromS3(fileFormat == FileFormat.LP ? "LP" : "TOU");
           foreach (var fileName in fileNames)
           {
               var rawData = CsvReader
                   .ReadFromText(await File.ReadAllTextAsync(fileName))
                   .Select(record => GetRecord(fileFormat, record));
               Console.WriteLine($"Got {rawData.Count()} records for {fileName} with format {fileFormat}.");
               var groupedData = from record in rawData
                   group record by new
                   {
                       record.MeterCode,
                       record.DataType,
                       record.Date
                   }
                   into groupedRecord
                   select groupedRecord;
            
               var results = groupedData
                   .Select(group => new ResultsItem
                       {
                           resultId = Guid.NewGuid().ToString("n"),
                           Date = group.Key.Date,
                           DataType = group.Key.DataType,
                           MeterCode = group.Key.MeterCode,
                           Minimum = group.Min(x => x.DataValue),
                           Maximum = group.Max(x => x.DataValue),
                           Median = group.Select((x => x.DataValue)).Median()
                       }
                   );

               var clientFactory = new AwsClientFactory<AmazonDynamoDBClient>();
               var dynamoDbClient = clientFactory.GetAwsClient();
            
               foreach (var result in results)
               {
                   await InsertRecord(dynamoDbClient, result);
               }
               File.Delete(fileName);
           }
       }
       
       public async Task<Response> Handle(Request request, ILambdaContext lambdaContext)
       {
           await ProcessFiles(FileFormat.LP);
           await ProcessFiles(FileFormat.TOU);
           return new Response { Message = "Successfully processed files."};
       }
    }
}
