#!/bin/bash

#install zip on debian OS, since microsoft/dotnet container doesn't have zip by default
if [ -f /etc/debian_version ]
then
  apt -qq update
  apt -qq -y install zip
fi

echo "Running dotnet restore"
dotnet restore

echo "Running unit tests..."
dotnet test

echo "Running package..."
pushd src
dotnet lambda package --configuration release --framework netcoreapp2.1 --output-package bin/release/netcoreapp2.1/erm-dataapi.zip
popd