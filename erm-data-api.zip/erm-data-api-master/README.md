# ERM Data API

[![Actions Status](https://github.com/jonparker/erm-data-api/workflows/Serverless%20.NET%20Core/badge.svg)](https://github.com/{owner}/{repo}/actions)

## Overview

The ERM Data API is an API for injesting, analysing and reporting on ERM data.

## Architecture

The API runs on AWS.
The architecture of involves:

1. API Gateway
2. Lambdas
3. S3
4. DynamoDB

Here is a diagram of the architecture:

![AWS Architecture](images/erm-data-api-architecture.png)

The API involves an API Gateway and two C# .NET Core 2.1 lambdas that integrate with an S3 bucket and DynamoDB table.
The `aggregate` lambda retrieves all the file from S3 and analyses them and stores the results in DynamoDB.
Th `display` lambda handles retrieves the data from DynamoDB and returns in the response.

## Deployment

This project will be deployed to AWS on push to the master branch. It uses GitHub Actions to do the build and deployment and GitHub secrets for the AWS credentials. These credentials need access to CloudFormation in order to deploy the stack.

## Assumptions and Architectural Reasoning

The core assumptions with the calculations are:

1. The calculations of minimum, maximum and median should be included in the API while the raw data should be excluded.
2. Each file will contain data for a separate date or meter code
3. The solution will be required to scale to large numbers of files
4. The combined total of all files will be no more than 500MB in size (the lambda has been given 1GB of RAM to process a file and has 500MB of temp storage). This limitation could be removed by batch processing the files or triggering the lambda to run based off an S3 event.
5. Complicated analysis or filtering of data is not required on the results. For this reason I have kept the solution simple and avoided using Redshift to store the data as that would add to the cost and complexity of the solution.
6. The final assumption is that the data files will contain the same column headers for all files.
7. The API does not need to be protected and is accessible to the internet.
8. Both the LP and TOU data sets have equivalent data and should be combined together into a single result.
9. The `aggregate` lambda assumes that files of type `LP` will be uploaded into an `LP` folder and files of type `TOU` will be uploaded into a `TOU` folder in S3.

Other than lambda concurrency limits there is no capacity planning required for the solution and so it is the simplest in regards to scalability and maintainability.

## Testing

In order to invoke the lambda functions using the serverless cli you must deploy the project via the serverless cli rather than via the Github deployment.

To invoke a function from the CLI run:

1. Upload the files to S3 into folders `LP` and `TOU`.
2. Run `sls invoke --function aggregate` to run the calculations.
3. Run `sls invoke --function display` to retrieve the results.

A sample of the response from the `display` lambda is in the `/test-results` folder.
Future improvements would include adding unit and integration tests which I was not able to complete in the time available.
